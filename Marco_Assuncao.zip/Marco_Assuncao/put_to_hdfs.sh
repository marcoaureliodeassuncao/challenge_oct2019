#! /bin/bash


# Comando put dos arquivos .csv e do arquivo .jar
echo 'colocando os arquivos nos diretórios do HDFS'
hdfs dfs -put $PWD/MarcoAssuncao/crawler_dolar/scrapDolar.csv /user/MarcoAssuncao/input
hdfs dfs -put $PWD/MarcoAssuncao/crawler_crypto/scrapCrypto.csv /user/MarcoAssuncao/input
hdfs dfs -put $PWD/MarcoAssuncao/bin/scala_dir_2.11-0.1-SNAPSHOT.jar /user/MarcoAssuncao
echo 'arquivos movidos'


# movendo csv's transferidos e comprimindo-os
echo 'movendo e zippando os arquivos .csv'
mv $PWD/MarcoAssuncao/crawler_dolar/scrapDolar.csv $PWD/MarcoAssuncao/crawler_dolar/transferidos/scrapDolar.csv
zip -r $PWD/MarcoAssuncao/crawler_dolar/transferidos/$(date '+%Y-%m-%d')_Dolar.zip $PWD/MarcoAssuncao/crawler_dolar/transferidos/scrapDolar.csv
mv $PWD/MarcoAssuncao/crawler_crypto/consolidados/scrapCrypto.csv $PWD/MarcoAssuncao/crawler_crypto/consolidados/transferidos/scrapCrypto.csv
zip -r $PWD/MarcoAssuncao/crawler_crypto/consolidados/transferidos/$(date '+%Y-%m%-d').zip $PWD/MarcoAssuncao/crawler_crypto/consolidados/transferidos/scrapCrypto.csv
echo 'arquivos movidos e comprimidos'
