#! /bin/bash


# Comando put dos arquivos .csv
echo 'colocando os arquivos nos diretórios do HDFS'
hdfs dfs -put $PWD/MarcoAssuncao/crawler_dolar/scrapDolar.csv /user/MarcoAssuncao/input
hdfs dfs -put $PWD/MarcoAssuncao/crawler_crypto/scrapCrypto.csv /user/MarcoAssuncao/input
echo 'arquivos movidos'


# movendo csv's transferidos e comprimindo-os
mv MarcoAssuncao/crawler_dolar/scrapDolar.csv transferidos/scrapDolar.csv
zip -r $(date '+%Y%m%d').zip ~/MarcoAssuncao/scrapDolar.csv
mv MarcoAssuncao/crawler_crypto/scrapCrypto.csv transferidos/scrapCrypto.csv
zip -r $(date '+%Y%m%d').zip ~/MarcoAssuncao/scrapCrypto.csv
