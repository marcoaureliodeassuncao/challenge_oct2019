#! /bin/bash

python $PWD/MarcoAssuncao/bin/scrap_dolar.py
python $PWD/MarcoAssuncao/bin/crypto_scrap2.py
mv scrapCrypto.csv $PWD/MarcoAssuncao/crawler_crypto/scrapCrypto.csv
mv scrapDolar.csv $PWD/MarcoAssuncao/crawler_dolar/scrapDolar.csv
