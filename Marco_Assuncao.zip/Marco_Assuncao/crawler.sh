#! /bin/bash

# Essa parte cuida por executar os crawlers e mover os seus respectivos csv's para seus diretórios
echo 'executando os crawlers'
python3 $PWD/MarcoAssuncao/bin/scrap_dolar.py
python3 $PWD/MarcoAssuncao/bin/crypto_scrap2.py
echo 'movendo os arquivos .csv para seus diretórios'
mv scrapCrypto.csv $PWD/MarcoAssuncao/crawler_crypto/scrapCrypto.csv
mv scrapDolar.csv $PWD/MarcoAssuncao/crawler_dolar/scrapDolar.csv
echo 'arquivos .csv movidos'
