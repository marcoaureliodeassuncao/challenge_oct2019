#! /bin/bash


# executa o arquivo .jar
echo 'executando spark submit'
source ~/.bashrc
export PATH=$PATH:$SPARK_HOME:/app/jdk/bin/
spark-submit /user/MarcoAssuncao/scala_dir_2.11-0.1-SNAPSHOT.jar --class $SPARK_PROGRAM_CLASS $sPARK_PROGRAM_JAR
echo 'spark executado, arquivo .json gerado'


# movendo json para o diretório de tranferidos
echo 'movendo diretório no hdfs'
hdfs dfs -mv /user/MarcoAssuncao/output/Json /user/MarcoAssuncao/output/transferidos/$(date "+%Y-%m-%d")
echo 'arquivos movidos'
