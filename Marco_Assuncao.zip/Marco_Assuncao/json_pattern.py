import json
import os
from datetime import date

x=''
with open('{}/{}.json'.format(os.path.abspath(x),str(date.today().strftime("%Y%m%d"))), 'r') as file:

	content = file.read().splitlines()

	with open('{}/MarcoAssuncao/processados_json/{}.json'.format(os.path.abspath(x), date.today()), 'w') as json_file:
		for item in content:
			json.dump({"index":{}}, json_file)
			json_file.write('\n')
			json.dump(json.loads(item), json_file)
			json_file.write('\n')
