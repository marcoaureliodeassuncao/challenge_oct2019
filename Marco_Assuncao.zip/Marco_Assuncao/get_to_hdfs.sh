#1 /bin/bash

#resgatar o json do HDFS
echo 'pegando arquivo json do hdfs'
hdfs dfs -get /user/MarcoAssuncao/output/transferidos/$(date "+%Y-%m-%d")/*.json .
mv *.json $(date "+%Y-%m-%d").json
echo 'json resgatado do HDFS'


# formatando o json para o padrão de bulk do Elastic
python3 $PWD/MarcoAssuncao/bin/json_pattern.py
rm $PWD/*.json
echo 'json formatado para indexação'


# entrando no diretório do json
cd MarcoAssuncao/processados_json


# Assume-se que o servidor do ElasticSearch e do Kibana estejam rodando para se executar o mapping e criar o index

# Não estou restrigindo o número de shards e réplicas pois por algum motivo quando crio as visualizações ao testar manualmente ele buga e não consigo selecionar a cotação do dólar
# Mas para fazer isso só acrecentar no mapping o trecho abaixo

#  "settings": {
#                 "number_of_shards": 1,
#                 "number_of_replicas": 0
#                 }
#         }


#criar index no elastic
echo 'Criando o mapping no Elastic'
curl -X PUT "localhost:9200/marcoassuncao?pretty" -H 'Content-Type: application/json' -d'
{
 "mappings": {
  "doc": {
   "properties": {
    "Symbol": {"type": "text"},
    "Name": {"type": "text"},
    "Price (USD)": {"type": "float"},
    "Price (Real)": {"type": "float"},
    "Price (BTC)": {"type": "float"},
    "Chg (24H)": {"type": "text"},
    "Vol (24H)": {"type": "text"},
    "Timestamp":{"type": "date"}
   }
  }
 }
}
'
echo 'criando index no elastic'
curl -s -H 'Content-Type: application/x-ndjson' -XPOST 'localhost:9200/marcoassuncao/doc/_bulk?pretty' --data-binary @$(data "+%Y-%m-%d").json 
echo 'indice criado'


# voltando ao repositório inicial
cd


# Ao importar manualmente via console consigo mostrar as visualizaçõese o dashboard, entretanto ao fazer via curl este retorna um erro de mapper_parsing_exception, muito provavelmente porque, ao ser exportado, o arquivo vem como um array de jsons

# importando as visualizações e o dash via curl
echo 'importando as visualizações'
cd MarcoAssuncao/bin
curl -XPUT "http://localhost:9200/.kibana/visualization/Real?pretty" -H 'Content-Type: application/json' -H 'kbn-xsrf: true' --data-binary @Real.json
curl -XPUT "http://localhost:9200/.kibana/visualization/Crypto?pretty" -H 'Content-Type: application/json' -H 'kbn-xsrf: true' --data-binary @Crypto.json
curl -XPUT "http://localhost:9200/.kibana/visualization/Dollar?pretty" -H 'Content-Type: application/json' -H 'kbn-xsrf: true' --data-binary @Dollar.json
curl -XPUT "http://localhost:9200/.kibana/visualization/line_dash?pretty" -H 'Content-Type: application/json' -H 'kbn-xsrf: true' --data-binary @line_dash.json
curl -XPUT "http://localhost:9200/.kibana/dashboard/Challenge_dashboard?pretty" -H 'Content-Type: application/json' -H 'kbn-xsrf: true' --data-binary @dash.json


# movendo o json e zippando o arquivo
echo 'movendo e zippando o json indexado'
mv $PWD/MarcoAssuncao/processados_json/$(date "+%Y-%m-%d").json $PWD/MarcoAssuncao/processados_json/indexados/
zip -r $(date '+%Y%m%d').zip $PWD/MarcoAssuncao/processados_json/indexados/$(data "+%Y-%m-%d").json
echo 'arquivo .json comprimido e movido'
