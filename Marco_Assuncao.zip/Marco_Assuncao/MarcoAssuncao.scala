import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.sql._
import org.apache.spark.sql.SQLContext


object Try_join {

	def main (args: Array[String]) {
		val conf = new SparkConf().setAppName("Simple Application")
		val sc = new SparkContext(conf)
		val sqlc = new org.apache.spark.sql.SQLContext(sc)

		var dol = "/user/MarcoAssuncao/crawler_dolar/scrapDolar.csv"
		var cry = "/user/MarcoAssuncao/crawler_crypto/scrapCrypto.csv"

		val dol_cry_f1 = sqlc.read.format("com.databricks.spark.csv").option("header","true").option("inferSchema", "true").option("delimiter", ";").load(dol)

		val dol_cry_f2 = sqlc.read.format("com.databricks.spark.csv").option("header", "true").option("inferSchema", "true").option("delimiter", ";").load(cry)

		val dol_cry_f2_renamed = dol_cry_f2.withColumnRenamed("#","Id") 

		val dol_join_cry = dol_cry_f1.crossJoin(dol_cry_f2_renamed)

		val dol_join_cry_2 = dol_join_cry.drop("Id").drop("2019-05-07 14:30:47")

		val dol_join_cry_3 = dol_join_cry_2.withColumn("Price (Real)", dol_join_cry_2.col("Currency") * dol_join_cry_2.col("Price (USD)"))

		val df_to_json = dol_join_cry_3.drop("Coin").drop("Currency").drop("Change").drop("Percentual").drop("Chg (7D)").drop("Market Cap").drop("Total Vol")

		val df_to_json_2 = df_to_json.select("Symbol","Name","Price (USD)","Price (Real)","Price (BTC)","Chg (24H)","Vol (24H)","Timestamp")

		df_to_json_2.write.format("json").save("/user/MarcoAssuncao/output/Json")

	}
}
